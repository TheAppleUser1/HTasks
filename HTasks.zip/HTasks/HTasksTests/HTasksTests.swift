//
//  HTasksTests.swift
//  HTasksTests
//
//  Created by Apple on 2025. 03. 29..
//

import Testing
@testable import HTasks

struct HTasksTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
