//
//  HTasksApp.swift
//  HTasks
//
//  Created by Apple on 2025. 03. 29..
//

import SwiftUI

@main
struct HTasksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
